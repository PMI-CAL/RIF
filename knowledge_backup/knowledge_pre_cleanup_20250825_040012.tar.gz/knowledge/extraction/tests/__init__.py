"""
Test package for entity extraction system.
"""