"""
Test package for embedding generation system.
"""