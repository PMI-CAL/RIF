"""
Tests for DuckDB database implementation.
Issue #26: Set up DuckDB as embedded database with vector search
"""