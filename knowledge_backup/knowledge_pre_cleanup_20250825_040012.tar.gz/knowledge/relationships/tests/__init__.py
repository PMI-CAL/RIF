"""
Test suite for relationship detection system.
"""

from .test_relationship_types import *
from .test_relationship_detection import *
from .test_storage_integration import *